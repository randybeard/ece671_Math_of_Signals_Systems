function J = modgcvfun(alpha,s1,U1,ph)
%MODGCVFUN Modified Generalized Cross Validation (GCV). 
% J = modgcvfun(alpha,s1,U1,ph) performs a modified 
%   GCV to optimize the regularization parameter
%   ALPHA for use in a modified Tikhonov filter.  
%
%
% Description:
%
%  Modified Generalized 
%  Cross-Validation
%
% Inputs:
%
% Outputs:
%
%   Reference:
%       E. G. Williams, "Regularization methods for 
%       near-field acoustical holography," J. Acoust. 
%       Soc. Am. 110, 1976-1988 (2001).
% 
% Author: Kent L. Gee

%generate filter
% (See Williams (2001), Eq. 57)
F1alpha1=diag(alpha./(alpha+s1.^2.*((alpha+s1.^2)/alpha).^2));
%cost function
% (See Williams (2001), Eq. 58)
J=norm(F1alpha1*U1'*ph)^2/trace(F1alpha1)^2;