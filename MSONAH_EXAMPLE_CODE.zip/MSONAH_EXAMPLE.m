clear; close all;

%Create measurement and reconstruction grids
[ms.X,ms.Y,ms.Z] = ndgrid(0.2, -1:0.1:1, -1:0.1:1);
[rc.X,rc.Y,rc.Z] = ndgrid(0.01, -1:0.1:1, -1:0.1:1);

%Generate measurement pressures at a frequency of 1000 Hz
p = sourcex(ms,1000);

%Run M-SONAH to get reconstructed pressures near the sources
pr = sonahmstr2cyl(ms,reshape(p,[numel(p) 1]),...
  rc,1000,1,0.5);
pr = reshape(pr,size(rc.X));

%% Plot

%Plot measurement (input to M-SONAH)
figure
subplot(1,2,1)
pcolor(squeeze(ms.Z),squeeze(ms.Y),...
  squeeze(10*log10(abs(p).^2)))
shading flat; axis image;
xlabel('{\itz} (m)'); ylabel('{\ity} (m)')
title('Measurement, {\itx}=0.2 m')
h = colorbar; ylabel(h,'SPL')
set(gca,'FontName','Times New Roman','FontSize',20)
set(h,'FontName','Times New Roman','FontSize',20)

%Plot reconstructed pressures (output from M-SONAH)
subplot(1,2,2)
pcolor(squeeze(rc.Z),squeeze(rc.Y),...
  squeeze(10*log10(abs(pr).^2)))
shading interp; axis image; 
xlabel('{\itz} (m)'); ylabel('{\ity} (m)')
title('Reconstruction, {\itx}=0.01 m')
h = colorbar; ylabel(h,'SPL')
set(gca,'FontName','Times New Roman','FontSize',20)
set(h,'FontName','Times New Roman','FontSize',20)
