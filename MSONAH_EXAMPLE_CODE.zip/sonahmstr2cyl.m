function pr = sonahmstr2cyl(ms,p,rc,f,gv,d,m,ks)
%SONAHMSTR2CYL Multisource-type representation statistically 
%   optimized near-field acoustical holography: Two 
%   cylinder-type sources.  
%   
%   PR = SONAHMSTR2CYL(MS,P,RC,F) performs an 
%   NAH sound field reconstruction at locations RC, 
%   using measured hologram data P at 
%   locations MS.  The frequency (in Hz) is 
%   specified by F.
%
%   MS is a structured array of three elements:
%
%       ms.X, ms.Y, and ms.Z.  
%
%   Each element of MS is a three-dimensional array 
%   of the locations of measurement points in their 
%   respective Cartesian coordinates, (x,y,z).
%
%   RC is a structured array, RC, or a cell array 
%   of structured arrays, RC.{Q}, in the case of 
%   multiple sets of reconstruction locations.  It 
%   has three elements:
%
%       rc.X, rc.Y, and rc.Z.
%
%   Each element of RC is a three-dimensional array 
%   of the locations of reconstruction points in 
%   their respective Cartesian coordinates, (x,y,z).  
%
%   P is the matrix of hologram pressures.  Each
%   column of P is a partial field, and each row 
%   is the complex pressure at a hologram 
%   location, with 
%
%       length(p(:,1)) = numel(ms.X).
%
%   PR = SONAHMSTR2CY(MS,P,RC,F,1) is the same as 
%   SONAHMSTR2CYL(MS,P,RC,F), and does not employ 
%   global variables.  
%   PR = SONAHMSTR2CY(MS,P,RC,F,2) defines variables 
%   A, U, G, V, and RALPHA as global variables, so 
%   that they are not recreated with each call of 
%   SONAHMSTR2CYL.
%
%   PR = SONAHMSTR2CY(MS,P,RC,F,GV,D) locates the 
%   origin of each set of cylindrical wave functions
%   a distance D from the y axis.  The nozzle center 
%   of an F-22A is 75 inches from the ground.  
%   PR = SONAHMSTR2CY(MS,P,RC,F,GV) uses 
%   D = 75 * 0.0254;
%
%   PR = SONAHMSTR2CY(MS,P,RC,F,GV,D) uses M = 0.
%   PR = SONAHMSTR2CY(MS,P,RC,F,GV,D,M) includes 
%   Hankel functions of orders -M through M in the
%   expansion.
%
%   PR = SONAHMSTR2CY(MS,P,RC,F,GV,D,M) uses KS = 1.
%   PR = SONAHMSTR2CY(MS,P,RC,F,GV,D,M,KS) scales 
%   the maximum wave number in the axial direction 
%   by KS.  With KS = 1, the maximum wave number is 
%   PI divided by the axial grid spacing of the 
%   hologram grid, 
%
%   The regularization is capable of running in 
%   parallel, for speed.  If desired, use the command
%   MATLABPOOL OPEN N, where N is the number of
%   processors to be used, prior to calling 
%   SONAHMSTR2CYL.
%
%   See also SONAHPL, SONAHCYL.
%
%   Subroutines:
%   CSVD, MODGCVFUN
%
%   References:
%   Y. T. Cho and J. S. Bolton, "Source visualization by using
%   statistically optimized near-field acoustical holography in
%   cylindrical coordinates", J. Acoust. Soc. Am. 118, 2355-
%   2364 (2005).
%
%   E. G. Williams, "Regularization methods for near-field 
%   acoustical holography," J. Acoust. Soc. Am. 110, 1976-1988 
%   (2001).
%
%   J. Hald, "Basic theory and properties of statistically 
%   optimized near-field acoustical holography", J. Acoust. 
%   Soc. Am. 125, 2105-2120 (2009).
%
%   A. T. Wall, K. L. Gee, T. B. Neilsen and M. M. James, 
%   The characterization of military aircraft jet noise 
%   using near-field acoustical holography methods, Chapter 5, 
%   (Dissertation, Brigham Young University, Provo, UT, 2013).

if gv == 2
    %create global variables
    disp('Global variables created.')
    global A Ralpha %#ok<TLEV> 
elseif nargin < 5 || gv == 1
    disp('No global variables.')
    A = [];
else
    disp('Error: Incorrect choice for global variable creation.')
    return
end
if nargin < 6, d = 75 * 0.0254; end
if nargin < 7
    m = 0;
elseif mod(m,1)
    disp('Hankel orders must be of integer value.')
    return
end
if nargin < 8, ks = 1; end    

%define constants
c=343;              %Speed of sound
k=2*pi*f/c;         %Wave number

%generate wavenumber space parameters
%maximum kz (See Cho (2005), Eq. 11)
% Note: if you are getting poor results, this is the 
% first parameter I would adjust.  
kzmax = abs(pi / diff(ms.Z (1, 1, 1 : 2))) * ks;
%delta kz (See Cho (2005), Eq. 25; Hald (2009), Eq. 18 
%and respective paragraph)
dkz = abs(2 * pi / (abs(ms.Z(1, 1, end) - ms.Z(1, 1, 1))) / 2);  
%array of kz values
kz = -kzmax : dkz : kzmax;

%array of kr values (See Cho (2005), Eq. 3)
kr = sqrt(k ^2 - kz .^2);   

%transform to first cylindrical coordinate system` 
ms.PHIup = atan((ms.Y - d) ./ ms.X);
ms.Rup = sqrt(ms.X .^2 + (ms.Y - d) .^2);
rc.PHIup = atan((rc.Y - d) ./ rc.X);
rc.Rup = sqrt(rc.X .^2 + (rc.Y - d) .^2);
%transform to second cylindrical coordinate system
ms.PHIdn = atan((ms.Y + d) ./ ms.X);
ms.Rdn = sqrt(ms.X .^2 + (ms.Y +d ) .^2);
rc.PHIdn = atan((rc.Y + d) ./ rc.X);
rc.Rdn = sqrt(rc.X .^2 + (rc.Y + d) .^2);

%reference radius
% In some cases, I have found the stability of my final 
% result to be highly sensitive to this parameter.
rs = 1/.000005; %See Cho (2005)

%define cylindrical wave functions (See Cho (2005), Eq. 5)
% Note: The last value in the BESSELJ function, 1, gives 
% the function a scaling factor to prevent instabilities.  
% If your answer is blowing up, please use this 
% instead of searching for the problem for two 
% weeks straight.
% Note: The formula given here (besselj - 1i*bessely) is 
% for a Hankel function of the SECOND kind. In the 
% literature, Hankel functions of the first kind  
% represent outward propagation, and Hankel functions of the
% second kind are for inward.  However, due to the way 
% Matlab defines the imaginary unit, the present 
% formulation is required.
Phi = @(r, phi, z, b) (besselj(b, kr * r, 1) - ...
    1i * bessely(b, kr * r, 1)) ./ (besselj(b, kr * rs, 1) - ...
    1i * bessely(b, kr * rs, 1)) .* exp(1i * (b * phi + kz * z));

if isempty(A)
    
    %form A, a matrix of wave functions.  
    % The size of A is (number of wavefunctions, number of 
    % measurement points).  (See Cho (2005), Eq. 12a)    
    A = zeros(2*numel(kr)*numel(-m:m), numel(ms.X));
    for zz = 1 : length(ms.Z(1,1,:))
        for yy = 1 : length(ms.Y(1,:,1))
            for xx = 1 : length(ms.X(:,1,1))
                i = numel(ms.X(:,:,1))*(zz-1)+ ...
                    length(ms.X(:,1,1))*(yy-1)+xx;
                for mm = -m : m
                    %first set of cylindrical wave functions
                    A(1+length(kr)*(mm+m) : length(kr)* ...
                        (mm+1+m), i) = Phi(ms.Rup(xx,yy,zz), ...
                        ms.PHIup(xx,yy,zz), ms.Z(xx,yy,zz), mm);
                    %second set of cylindrical wave functions
                    A(length(kr)*length(-m:m) + ...
                        (1+length(kr)*(mm+m) : length(kr)* ...
                        (mm+1+m)), i) = Phi(ms.Rdn(xx,yy,zz), ...
                        ms.PHIdn(xx,yy,zz), ms.Z(xx,yy,zz), mm);
                end
            end
        end
        disp(['Form A: ',...
            num2str(round(1000*zz/length(ms.Z(1, 1, :)))/10),...
            '%']);
    end

    %regularized inverse
    % (See Cho (2005), Eq. 32)
    Ralpha = mtreg(A, p, kr);
end

%form alpha, a matrix of wave functions.
% The size of alpha is (number of wavefunctions, 
% number of measurement points).  (See Cho (2005), Eq. 12b)
alpha = zeros(numel(kz) * numel(-m : m), numel(rc.X));
for zz = 1 : length(rc.Z(1, 1, :))
    for yy = 1 : length(rc.Y(1, :, 1))
        for xx = 1 : length(rc.X(:, 1, 1))
            i = numel(rc.X(:,:,1))*(zz-1) + ...
                length(rc.X(:,1,1))*(yy-1) + xx;
            for mm = -m : m
                %first set of cylindrical wave functions
                alpha(1+length(kr)*(mm+m) : length(kr) * ...
                    (mm+1+m), i) = Phi(rc.Rup(xx, yy, zz), ...
                    rc.PHIup(xx, yy, zz), rc.Z(xx, yy, zz), mm);
                %second set of cylindrical wave functions
                alpha(length(kr)*length(-m:m)+...
                    (1+length(kr)*(mm+m) : length(kr)* ...
                    (mm+1+m)), i) = Phi(rc.Rdn(xx,yy,zz), ...
                    rc.PHIdn(xx,yy,zz), rc.Z(xx,yy,zz), mm);
            end
        end
    end
    disp(['Form alpha: ',...
        num2str(round(1000*zz/length(rc.Z(1,1,:)))/10),...
        '%']);
end

%reconstruct pressures
% (See Cho (2005), Eqs. 27-30)
disp('Reconstruction: Working...')
pr = zeros(numel(rc.Z), length(p(1, :)));
for pfn = 1 : length(p(1, :))
    pr(:, pfn) = p(:, pfn).' * Ralpha(:, :, pfn) * A' * alpha;
end

clear alpha

