function ralpha = mtreg(A,ph,kr)
%MTREG Modified Tikhonov regularization.
% RALPHA = MTREG(A,PH) generates a modified
%   Tikhonov regularization filter, using
%   generalized cross-validation (GCV) to
%   optimize the filter parameter.  A is the 
%   cross spectral matrix of wave functions.
%   PH is the vector of hologram pressures.
%
%   RALPHA is the regularized inverse of the
%   cross spectral matrix.
%
%   References:
%   E. G. Williams, "Regularization methods for
%   near-field acoustical holography," J. Acoust.
%   Soc. Am. 110, 1976-1988 (2001).
%
%   Y. T. Cho and J. S. Bolton, "Source 
%   visualization by using statistically optimized 
%   near-field acoustical holography in cylindrical 
%   coordinates", J. Acoust. Soc. Am. 118, 2355-
%   2364 (2005).

%take SVD 
% (See Cho (2005), Eq. 31)
disp('SVD: Working...');
pause(0.1)
[V, s, U] = csvd(A' * A);
%rough filter
% A cutoff of noise-related singular values is necessary
% here to prevent instabilities.
NUM = sum(kr > 0);
s(round(NUM * 2 + 1) : end) = 0;

alphara = logspace(-45, 45, 45);    %alpha array
ralpha = zeros([size(A'*A) length(ph(1,1,:))]);
for pfn = 1 : length(ph(1, :))
    disp(['Regularization, PF ',num2str(pfn),...
        ': Working...']);
    J = zeros(1, length(alphara));
    parfor n = 1 : length(alphara)
        %generate filter funtion
        % (See Williams (2001), Eq. 57)
        F1alpha1 = diag(alphara(n) ./ ...
            (alphara(n) + s.^2 .* ...
            ((alphara(n) + s.^2) / alphara(n)).^2));
        %cost function
        % (See Williams (2001), Eq. 58)
        J(n) = norm(F1alpha1*U'*ph)^2 / trace(F1alpha1)^2;
    end
    
    %minimization of J
    [~, ind] = min(J);
    alphalow = alphara(ind);
    ra = fminbnd('modgcvfun', .01*alphalow, 100*alphalow, ...
        optimset('Display', 'off'), s, U, ph);
    
    %modified Tikhonov filter
    % (See Cho (2005), Eq. 33 and respective paragraph,
    % and Williams (2001), Eq. 57)
    g=diag(s);
    F1a = diag(ra ./ (ra + s .^2 .* ...
        ((ra + s .^2) / ra) .^2));
    % (See Cho (2005), Eq. 32)
    ralpha(:,:,pfn) = V * ...
        (ra * F1a .^2 + g' * g)^(-1) * g' * V';
end



