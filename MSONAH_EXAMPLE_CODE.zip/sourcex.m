function p = sourcex(meas,f)
% MSTRNUM Multi-source-type represetation statistically optimized
% near-field acoustical holography experiment for a numerical source.
%   MSTRNUM(F,D,SDIRECT,SIG) performs a numerical MSTR SONAH 
%   experiment on two correlated line arrays of point monopoles, 
%   radiating at frequency F.  MSTR SONAH reconstruction of the 
%   source is performed, along with a planar SONAH and cylindrical 
%   SONAH reconstruction of the same data.  These reconstructions 
%   and a benchark measurement are saved in the directory SDIRECT.
%
%   D is a two-element vector, where D(1) is the measurement standoff
%   distance, and D(2) is the reconstruction standoff distance.
%
%   MSTRNUM(F,D,SDIRECT,1) generates unweighted source arrays
%   MSTRNUM(F,D,SDIRECT,2) generates Gaussian-weighted source arrays
%
%   MSTRNUM(F,D,SDIRECT,1) is the same as MSTRNUM(F,D,SDIRECT)
%
%   Data are saved in the files MSTRNUM_DATA_*.
%
%   See also MSTRNUM2, MSTRJET.
%
%   Subroutines:
%   SONAHMSTR2CYL, SONAHCYL, SONAHPL.
%
%   Reference:
%   A. T. Wall, K. L. Gee and T. B. Neilsen, "Multi-source-type 
%   representation statistically optimized near-field acoustical 
%   holography," J. Acoust. Soc. Am.,  (pending submission).

%define constants
rho0 = 1.21;    %air desnity, kg/m^3.
c = 343;    %speed of sound, m/s;
k = 2*pi*f/c;   %wavenumber, m^-1;

%generate directional sources
N = 51;	%number of sources (each array)
src.X = 0;	%source x location
src.Y = .5;	%source y location
src.Yi = -.5;	%image source y location
src.Z = linspace(-0.5, 0.5, N);	%source z-location array
Q = 1;	%source strengths
dz = diff(src.Z(1 : 2));  

%Gaussian weighting
sigma = (src.Z(end) - src.Z(1)) / 4; 
ww = exp(-(src.Z - mean(src.Z)) .^2 / (2 * sigma^2 ));  

phi = 90;  %source directivity angle
theta = 2 * pi * f * dz * (0 : N - 1) * cosd(phi) / c;  

%simulate measurement
p_all = zeros([size(meas.Z) N]);
for n = 1:N
    %soure-to-measurement distances
    R = sqrt((meas.Z - src.Z(n)) .^2 + (meas.X - src.X) .^2 + ...
        (meas.Y - src.Y) .^2 );
    Ri = sqrt((meas.Z - src.Z(n)) .^2 + (meas.X - src.X) .^2 + ...
        (meas.Y - src.Yi) .^2 );
    %measured pressures usng Green's functions
    p_all(:, :, :, n) = ww(n) * 1i * rho0 * c * k * Q / (4 *pi) .* ...
        (exp(-1i * k .* R) ./ R + exp(-1i * k .* Ri) ./ Ri) * ...
        exp(1i * theta(n));
end
p = sum(p_all,4);



